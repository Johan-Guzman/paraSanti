package com.example.demo.controller;
import com.example.demo.model.Products;
import com.example.demo.services.IProductsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private IProductsService productsService;


    @GetMapping
    public String index(Model model) {
        model.addAttribute("products", productsService.getAllProducts());
        return "index";
    }


    @GetMapping("/list")
    public String list(Model model) {
        model.addAttribute("products", productsService.getAllProducts());
        return "products/list";
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Products product = productsService.getProductById(id);
        model.addAttribute("product", product);
        return "products/detail";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("product", new Products());
        model.addAttribute("title", "Crear producto");
        return "products/form";
    }

    @PostMapping
    public String create(@ModelAttribute("product") @Valid Products product, BindingResult result) {
        if (result.hasErrors()) return "products/form";
        productsService.createProduct(product);
        return "redirect:/products";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, Model model) {
        Products product = productsService.getProductById(id);
        model.addAttribute("product", product);
        model.addAttribute("title", "Editar producto");
        return "products/form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable Long id, @ModelAttribute("product") @Valid Products product, BindingResult result) {
        if (result.hasErrors()) return "products/form";
        productsService.updateProduct(id,product);
        return "redirect:/products/" + id;
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id) {
        productsService.deleteProduct(id);
        return "redirect:/products";
    }
}
